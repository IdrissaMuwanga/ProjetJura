<footer class="footer bg-primary text-center text-white">
  <!-- Grid container -->
  <div class="container p-4">

    <script>
      var myModal = document.getElementById('myModal')
      var myInput = document.getElementById('myInput')

      myModal.addEventListener('shown.bs.modal', function() {
        myInput.focus()
      })
    </script>

    <!-- Section: Text -->
    <section class="mb-4">
      <p>
        CVVEN
      </p>
    </section>
    <!-- Section: Text -->


  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
    © 2022 Copyright:
    <a class="text-white" href="https://github.com/Kenthyvuth/ProjetJura/">Projet Jura BTS SIO SLAM</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
</body>

</html>