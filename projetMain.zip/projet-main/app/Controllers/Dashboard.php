<?php

namespace App\Controllers;

use \Core\View;
use App\Models\ConnexionModel;

class Dashboard extends BaseController
{
    public function index()
    {
        $session = session();
        echo "Welcome back, ".$session->get('nomClient');
    }
    public function admin()
    {
        $session = session();
        echo " gg t'es admin, ".$session->get('nomClient');
    }

}